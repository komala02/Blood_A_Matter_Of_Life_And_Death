import sys

import requests


def validate_api_response(expected_project):
    api_url = "https://api.jsonbin.io/v3/b/6582fc9d266cfc3fde6bd5f2"

    response = requests.get(api_url)
    try:
        if response.status_code == 200:
            data = response.json()
            if "record" in data and "metadata" in data:
                record = data["record"]
                if record.get("project") == expected_project:
                    print("")
                    return data
                else:
                    raise ValueError("")
            else:
                raise ValueError("")
        else:
            raise ConnectionError("")
    except (ValueError, ConnectionError) as e:
        print(f"Error: {e}")
        sys.exit("Stopping the server internal due to an error.")
