from flask import Blueprint, request, jsonify

from coredb.donation import add_donation, fetch_available_donors, get_ranking_table, fetch_donations_by_donor_id, \
    update_donation_status

donation_bp = Blueprint('donation', __name__)


@donation_bp.route('/donation', methods=['POST'])
def new_donation():
    try:
        data = request.json
        if 'donor' in data and 'receptor' in data:
            print(data)
            result = add_donation(data)
            return jsonify({"message": "Donation record created successfully"}), 201
        else:
            return jsonify({"error": "Missing donor or receptor data"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@donation_bp.route('/donation/<donation_id>/status', methods=['PATCH'])
def update_donation_status_api(donation_id):
    try:
        new_status = request.json.get('status')
        validate_status(new_status)
        if not new_status:
            return jsonify({"error": "Missing 'status' field in request body"}), 400

        update_donation_status(donation_id, new_status)
        return jsonify({"message": f"Donation status updated to {new_status}"}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@donation_bp.route('/donation/<donor_id>', methods=['GET'])
def get_donations_by_donor_id(donor_id):
    try:
        donations = fetch_donations_by_donor_id(donor_id)
        if donations:
            return jsonify({"donations": donations}), 200
        else:
            return jsonify({"message": "No donations found for this donor ID"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@donation_bp.route('/donation', methods=['GET'])
def get_available_donors():
    try:
        blood_group = request.args.get('blood_group')
        city = request.args.get('city')
        user = request.args.get('id')

        if not blood_group or not city or not user:
            return jsonify({"error": "Blood group, city and user id are required parameters."}), 400
        print(blood_group, city, user)

        donors = fetch_available_donors(blood_group, city, user)
        return jsonify(donors)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def validate_status(profession_type):
    top_10_cities = ['approve', 'reject']

    if profession_type not in top_10_cities:
        raise ValueError(f"Invalid status type. Allowed values are: {', '.join(top_10_cities)}")


@donation_bp.route('/ranking', methods=['GET'])
def get_ranking():
    try:
        ranking_table = get_ranking_table()
        response = {
            "top_20_users": [{
                "id": user[0],
                "first_name": user[1],
                "last_name": user[2],
                "points": user[3]
            } for user in ranking_table]
        }
        return jsonify(response)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
