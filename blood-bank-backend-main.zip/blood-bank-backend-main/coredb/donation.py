import sqlite3
import uuid
from datetime import timedelta, date, datetime


def add_donation(data):
    db = sqlite3.connect("blood_bank.db")
    cursor = db.cursor()
    donation_id = str(uuid.uuid4())
    today_date = date.today().strftime("%Y-%m-%d")

    cursor.execute('''INSERT INTO donation (id, donor, receptor, status, date)
                      VALUES (?, ?, ?, ?, ?)''',
                   (donation_id, data['donor'], data['receptor'], "pending", today_date))
    db.commit()
    db.close()


def update_donation_status(donation_id, new_status):
    db = sqlite3.connect("blood_bank.db")
    cursor = db.cursor()

    cursor.execute('''UPDATE donation
                      SET status = ?
                      WHERE id = ?''',
                   (new_status, donation_id))
    db.commit()
    db.close()


def fetch_available_donors(blood_group, city, user):
    db = sqlite3.connect("blood_bank.db")
    cursor = db.cursor()

    six_months_ago = datetime.now() - timedelta(days=180)

    cursor.execute('''
        SELECT u.id, u.email, u.first_name, u.last_name, u.phone_number, u.blood_group, u.age, u.city 
        FROM users u
        LEFT JOIN donation d ON u.id = d.donor
        WHERE u.blood_group = ? AND u.city = ? AND u.id != ? 
            AND (d.donor IS NULL OR d.status = "reject")
        GROUP BY u.id
    ''', (blood_group, city, user))

    available_donors = cursor.fetchall()

    db.close()
    donors_list = []
    for donor in available_donors:
        donor_dict = {
            "id": donor[0],
            "email": donor[1],
            "first_name": donor[2],
            "last_name": donor[3],
            "phone_number": donor[4],
            "blood_group": donor[5],
            "age": donor[6],
            "city": donor[7],
        }
        donors_list.append(donor_dict)

    return donors_list


def get_ranking_table():
    db = sqlite3.connect("blood_bank.db")
    cursor = db.cursor()

    cursor.execute('''SELECT donor, COUNT(*) as points 
                      FROM donation 
                      where status == 'approve'
                      GROUP BY donor''')
    donation_points = {row[0]: row[1] for row in cursor.fetchall()}

    cursor.execute('''SELECT id, first_name, last_name 
                      FROM users''')
    users = cursor.fetchall()

    user_points = []
    for user in users:
        user_id = user[0]
        points = donation_points.get(user_id, 0)
        user_points.append((user_id, user[1], user[2], points))

    user_points.sort(key=lambda x: x[3], reverse=True)

    top_20_users = user_points[:20]

    db.close()

    return top_20_users


def fetch_donations_by_donor_id(donor_id):
    db = sqlite3.connect("blood_bank.db")
    cursor = db.cursor()

    cursor.execute('''SELECT * FROM donation WHERE donor = ?''', (donor_id,))
    donations = cursor.fetchall()

    db.close()
    return donations
