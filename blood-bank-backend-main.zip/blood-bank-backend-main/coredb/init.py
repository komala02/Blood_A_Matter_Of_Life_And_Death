import sqlite3


def startDb():
    db = sqlite3.connect("blood_bank.db")
    cursor = db.cursor()
    cursor.execute("PRAGMA foreign_keys = ON;")
    create_users_table(cursor)
    create_donation_table(cursor)
    db.commit()
    db.close()


def create_users_table(cursor):
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
    table_exists = cursor.fetchone()

    if table_exists:
        cursor.execute("DROP TABLE users")

    cursor.execute('''CREATE TABLE users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE,
        password TEXT,
        first_name TEXT,
        last_name TEXT,
        phone_number TEXT,
        blood_group TEXT,
        age TEXT,
        city TEXT
    )''')


def create_donation_table(cursor):
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='donation'")
    table_exists = cursor.fetchone()

    if table_exists:
        cursor.execute("DROP TABLE donation")

    cursor.execute('''CREATE TABLE donation (
        id TEXT PRIMARY KEY,
        donor TEXT,
        receptor TEXT,
        status TEXT,
        date TEXT
    )''')
