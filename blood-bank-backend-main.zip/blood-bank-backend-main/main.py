from flask import Flask

from coredb.init import startDb
from routes.donation import donation_bp
from routes.project import validate_api_response
from routes.user import user_bp
from flask_cors import CORS

app = Flask(__name__)
CORS(app)


app.register_blueprint(user_bp)
app.register_blueprint(donation_bp)

if __name__ == '__main__':
    #startDb()
    validate_api_response("Blood Bank")
    app.run(debug=False, port=5000)


